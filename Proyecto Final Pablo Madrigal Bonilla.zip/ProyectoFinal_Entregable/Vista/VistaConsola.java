package Vista;

import Modelo.Cancion;
import Modelo.ListaReproduccion;
import Modelo.Usuario;

import java.util.Scanner;

public class VistaConsola {
    private Scanner scanner = new Scanner(System.in);

    public void mostrarMensaje(String msg) {
        System.out.println(msg);
    }

    public void mostrarCancion(Cancion c) {
        System.out.println("Cancion: " + c.getNombre() + " - " + c.getArtista() + " - Album: " + c.getAlbum() + " ($" + c.getPrecio() + ")");
    }

    public void mostrarListaReproduccion(ListaReproduccion lista) {
        System.out.println("Lista: " + lista.getNombre() + " (" + lista.getCanciones().size() + " canciones)");
        for (Cancion c : lista.getCanciones()) {
            mostrarCancion(c);
        }
    }

    public void mostrarUsuario(Usuario u) {
        if (u.esAdministrador()) {
            System.out.println("Administrador: " + u.getNombreCompleto() + " - Usuario: " + u.getNombreUsuario());
        } else {
            System.out.println("Usuario Final: " + u.getNombreCompleto() + " - Usuario: " + u.getNombreUsuario());
        }
    }

    public int pedirOpcion() {
        System.out.print("Seleccione opción: ");
        while (true) {
            String input = scanner.nextLine();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Entrada inválida, ingrese un número: ");
            }
        }
    }

    public String pedirTexto(String prompt) {
        System.out.print(prompt + ": ");
        return scanner.nextLine();
    }
}
