package Vista;

import Modelo.Cancion;
import Modelo.ListaReproduccion;
import Modelo.Usuario;

import javax.swing.*;

public class VistaGrafica {

    public void mostrarMensaje(String msg) {
        JOptionPane.showMessageDialog(null, msg, "Mensaje", JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarCancion(Cancion c) {
        String mensaje = String.format(
            "Canción: %s\nArtista: %s\nÁlbum: %s\nPrecio: $%.2f",
            c.getNombre(), c.getArtista(), c.getAlbum(), c.getPrecio()
        );
        JOptionPane.showMessageDialog(null, mensaje, "Información de Canción", JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarListaReproduccion(ListaReproduccion lista) {
        StringBuilder sb = new StringBuilder();
        sb.append("Lista: ").append(lista.getNombre())
          .append(" (").append(lista.getCanciones().size()).append(" canciones)\n\n");
        for (Cancion c : lista.getCanciones()) {
            sb.append(c.getNombre()).append(" - ").append(c.getArtista()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Lista de Reproducción", JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarUsuario(Usuario u) {
        String tipo = u.esAdministrador() ? "Administrador" : "Usuario Final";
        String mensaje = String.format("%s:\nNombre completo: %s\nUsuario: %s", 
            tipo, u.getNombreCompleto(), u.getNombreUsuario());
        JOptionPane.showMessageDialog(null, mensaje, "Información de Usuario", JOptionPane.INFORMATION_MESSAGE);
    }

    public int pedirOpcion(String mensaje, String titulo, String[] opciones) {
        int seleccion = JOptionPane.showOptionDialog(
            null,
            mensaje,
            titulo,
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            opciones,
            opciones[0]
        );
        return seleccion; 
    }

    public String pedirTexto(String mensaje, String titulo) {
        return JOptionPane.showInputDialog(null, mensaje, titulo, JOptionPane.QUESTION_MESSAGE);
    }
}
