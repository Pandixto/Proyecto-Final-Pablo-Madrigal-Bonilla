package Modelo;

public class UsuarioImpl extends Usuario {
    private boolean administrador;

    public UsuarioImpl(String nombreCompleto, java.time.LocalDate fechaNacimiento, String nacionalidad,
                       String identificacion, String avatar, String correo,
                       String nombreUsuario, String contrasena, String tipo) {
        super(nombreCompleto, fechaNacimiento, nacionalidad, identificacion, avatar, correo, nombreUsuario, contrasena);
        this.administrador = "Administrador".equalsIgnoreCase(tipo);
    }

    @Override
    public boolean esAdministrador() {
        return administrador;
    }

    @Override
    public String getTipo() {
        return administrador ? "Administrador" : "Usuario Regular";
    }
}
