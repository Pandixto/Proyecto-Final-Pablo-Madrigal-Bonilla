package Modelo;

public class Reproductor {
     private Cancion cancionActual;

    public void reproducir(Cancion c) {
        this.cancionActual = c;
        System.out.println("Reproduciendo: " + c.getNombre() + " - " + c.getArtista());
    }

    public void detener() {
        if (cancionActual != null) {
            System.out.println("Pausa: " + cancionActual.getNombre());
            cancionActual = null;
        } else {
            System.out.println("No hay nada en reproducción.");
        }
    }

    public Cancion getCancionActual() {
        return cancionActual;
    }
}
