package Modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Cancion {
    private int id;
    private String nombre;
    private String genero;
    private String artista;
    private String compositor;
    private LocalDate fechaLanzamiento;
    private String album;
    private double precio;
    private List<Integer> calificaciones;
    private int vecesComprada;
    private int vecesEnListas;

    public Cancion(int id, String nombre, String genero, String artista,
                   String compositor, LocalDate fechaLanzamiento,
                   String album, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.genero = genero;
        this.artista = artista;
        this.compositor = compositor;
        this.fechaLanzamiento = fechaLanzamiento;
        this.album = album;
        this.precio = precio;
        this.calificaciones = new ArrayList<>();
        this.vecesComprada = 0;
        this.vecesEnListas = 0;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public String getArtista() { return artista; }
    public void setArtista(String artista) { this.artista = artista; }

    public String getCompositor() { return compositor; }
    public void setCompositor(String compositor) { this.compositor = compositor; }

    public LocalDate getFechaLanzamiento() { return fechaLanzamiento; }
    public void setFechaLanzamiento(LocalDate fechaLanzamiento) { this.fechaLanzamiento = fechaLanzamiento; }

    public String getAlbum() { return album; }
    public void setAlbum(String album) { this.album = album; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getVecesComprada() { return vecesComprada; }
    public int getVecesEnListas() { return vecesEnListas; }

    public List<Integer> getCalificaciones() { return calificaciones; }

    public double getCalificacionPromedio() {
        if (calificaciones.isEmpty()) return 0;
        double suma = 0;
        for (int cal : calificaciones) suma += cal;
        return suma / calificaciones.size();
    }

    public void agregarCalificacion(int calificacion) {
        if (calificacion >= 1 && calificacion <= 10) calificaciones.add(calificacion);
    }

    public void incrementarCompras() { vecesComprada++; }
    public void incrementarVecesEnListas() { vecesEnListas++; }

    @Override
    public String toString() {
        return nombre + " - " + artista + " - Album: " + album + " ($" + precio + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cancion cancion = (Cancion) o;
        return id == cancion.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
