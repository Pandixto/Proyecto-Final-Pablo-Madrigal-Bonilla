package Modelo;

import java.time.LocalDate;

public class Administrador extends Usuario {
    public Administrador(String nombreCompleto, LocalDate fechaNacimiento, String nacionalidad,
                         String identificacion, String avatar, String correo,
                         String nombreUsuario, String contrasena) {
        super(nombreCompleto, fechaNacimiento, nacionalidad, identificacion,
              avatar, correo, nombreUsuario, contrasena);
    }

    @Override
    public boolean esAdministrador() {
        return true;
    }
}
