package Modelo;

import java.time.LocalDate;

public class UsuarioFinal extends Usuario {
    private double saldo;

    public UsuarioFinal(String nombreCompleto, LocalDate fechaNacimiento, String nacionalidad,
                        String identificacion, String avatar, String correo,
                        String nombreUsuario, String contrasena) {
        super(nombreCompleto, fechaNacimiento, nacionalidad, identificacion,
              avatar, correo, nombreUsuario, contrasena);
        this.saldo = 2.99;
    }

    public double getSaldo() { return saldo; }
    public void setSaldo(double saldo) { this.saldo = saldo; }
    public void recargarSaldo(double monto) { this.saldo += monto; }

    @Override
    public boolean esAdministrador() {
        return false;
    }

    @Override
    public String toString() {
        return super.toString() + " | Saldo: $" + String.format("%.2f", saldo);
    }
}
