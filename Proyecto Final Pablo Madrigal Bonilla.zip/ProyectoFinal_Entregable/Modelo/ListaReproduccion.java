package Modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ListaReproduccion {
    private String nombre;
    private LocalDate fechaCreacion;
    private List<Cancion> canciones;

    public ListaReproduccion(String nombre) {
        this.nombre = nombre;
        this.fechaCreacion = LocalDate.now();
        this.canciones = new ArrayList<>();
    }

    public void agregarCancion(Cancion cancion) {
        canciones.add(cancion);
        cancion.incrementarVecesEnListas();
    }

    public double getCalificacionPromedio() {
        if (canciones.isEmpty()) return 0;
        double suma = 0;
        for (Cancion c : canciones) suma += c.getCalificacionPromedio();
        return Math.round(suma / canciones.size());
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public LocalDate getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDate fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public List<Cancion> getCanciones() { return canciones; }

    @Override
    public String toString() {
        return "Lista: " + nombre + " (" + canciones.size() + " canciones)";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ListaReproduccion that = (ListaReproduccion) o;
        return Objects.equals(nombre, that.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
}
