package DAO;

import Modelo.Cancion;
import java.util.List;

public interface CancionDAO {
    void insertar(Cancion cancion) throws Exception;
    void actualizar(Cancion cancion) throws Exception;
    void eliminar(int id) throws Exception;
    Cancion obtenerPorId(int id) throws Exception;
    List<Cancion> obtenerTodos() throws Exception;
}
