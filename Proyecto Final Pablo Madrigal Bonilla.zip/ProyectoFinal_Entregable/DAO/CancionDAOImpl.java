package DAO;

import Conexion.ConexionOracle;
import Modelo.Cancion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CancionDAOImpl implements CancionDAO {

    @Override
    public void insertar(Cancion c) throws Exception {
        String sql = "INSERT INTO CANCIONES (ID, NOMBRE, GENERO, ARTISTA, COMPOSITOR, FECHA_LANZAMIENTO, ALBUM, PRECIO) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexionOracle.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, c.getId());
            ps.setString(2, c.getNombre());
            ps.setString(3, c.getGenero());
            ps.setString(4, c.getArtista());
            ps.setString(5, c.getCompositor());
            ps.setDate(6, Date.valueOf(c.getFechaLanzamiento()));
            ps.setString(7, c.getAlbum());
            ps.setDouble(8, c.getPrecio());
            ps.executeUpdate();
        }
    }

    @Override
    public void actualizar(Cancion c) throws Exception {
        String sql = "UPDATE CANCIONES SET NOMBRE = ?, GENERO = ?, ARTISTA = ?, COMPOSITOR = ?, FECHA_LANZAMIENTO = ?, ALBUM = ?, PRECIO = ? WHERE ID = ?";
        try (Connection conn = ConexionOracle.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getGenero());
            ps.setString(3, c.getArtista());
            ps.setString(4, c.getCompositor());
            ps.setDate(5, Date.valueOf(c.getFechaLanzamiento()));
            ps.setString(6, c.getAlbum());
            ps.setDouble(7, c.getPrecio());
            ps.setInt(8, c.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws Exception {
        String sql = "DELETE FROM CANCIONES WHERE ID = ?";
        try (Connection conn = ConexionOracle.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public Cancion obtenerPorId(int id) throws Exception {
        String sql = "SELECT * FROM CANCIONES WHERE ID = ?";
        try (Connection conn = ConexionOracle.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Cancion(
                    rs.getInt("ID"),
                    rs.getString("NOMBRE"),
                    rs.getString("GENERO"),
                    rs.getString("ARTISTA"),
                    rs.getString("COMPOSITOR"),
                    rs.getDate("FECHA_LANZAMIENTO").toLocalDate(),
                    rs.getString("ALBUM"),
                    rs.getDouble("PRECIO")
                );
            }
            return null;
        }
    }

    @Override
    public List<Cancion> obtenerTodos() throws Exception {
        String sql = "SELECT * FROM CANCIONES";
        List<Cancion> lista = new ArrayList<>();
        try (Connection conn = ConexionOracle.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Cancion c = new Cancion(
                    rs.getInt("ID"),
                    rs.getString("NOMBRE"),
                    rs.getString("GENERO"),
                    rs.getString("ARTISTA"),
                    rs.getString("COMPOSITOR"),
                    rs.getDate("FECHA_LANZAMIENTO").toLocalDate(),
                    rs.getString("ALBUM"),
                    rs.getDouble("PRECIO")
                );
                lista.add(c);
            }
        }
        return lista;
    }
}
