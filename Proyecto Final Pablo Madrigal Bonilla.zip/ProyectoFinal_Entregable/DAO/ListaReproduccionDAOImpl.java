package DAO;

import Modelo.ListaReproduccion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ListaReproduccionDAOImpl implements ListaReproduccionDAO {

    private Connection conn;

    public ListaReproduccionDAOImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void crearLista(ListaReproduccion lista) throws SQLException {
        String sql = "INSERT INTO LISTAS_REPRODUCCION (NOMBRE, FECHA_CREACION) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, lista.getNombre());
            stmt.setDate(2, Date.valueOf(lista.getFechaCreacion()));
            stmt.executeUpdate();
        }
    }

    @Override
    public ListaReproduccion obtenerListaPorNombre(String nombre) throws SQLException {
        String sql = "SELECT * FROM LISTAS_REPRODUCCION WHERE NOMBRE = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new ListaReproduccion(
                    rs.getString("NOMBRE")
                );
            }
        }
        return null;
    }

    @Override
    public List<ListaReproduccion> listarListas() throws SQLException {
        List<ListaReproduccion> listas = new ArrayList<>();
        String sql = "SELECT * FROM LISTAS_REPRODUCCION";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                listas.add(new ListaReproduccion(
                    rs.getString("NOMBRE")
                ));
            }
        }
        return listas;
    }

    @Override
    public void actualizarLista(ListaReproduccion lista) throws SQLException {
        String sql = "UPDATE LISTAS_REPRODUCCION SET FECHA_CREACION = ? WHERE NOMBRE = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(lista.getFechaCreacion()));
            stmt.setString(2, lista.getNombre());
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminarLista(String nombre) throws SQLException {
        String sql = "DELETE FROM LISTAS_REPRODUCCION WHERE NOMBRE = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.executeUpdate();
        }
    }

    @Override
    public void insertar(ListaReproduccion lista) throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'insertar'");
    }

    @Override
    public void actualizar(ListaReproduccion lista) throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'actualizar'");
    }

    @Override
    public void eliminar(String nombre) throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'eliminar'");
    }

    @Override
    public ListaReproduccion obtenerPorNombre(String nombre) throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'obtenerPorNombre'");
    }

    @Override
    public List<ListaReproduccion> obtenerTodas() throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'obtenerTodas'");
    }
}
