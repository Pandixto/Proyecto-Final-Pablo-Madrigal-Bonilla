package DAO;

import Modelo.ListaReproduccion;

import java.sql.SQLException;
import java.util.List;

public interface ListaReproduccionDAO {
    void insertar(ListaReproduccion lista) throws Exception;
    void actualizar(ListaReproduccion lista) throws Exception;
    void eliminar(String nombre) throws Exception;
    ListaReproduccion obtenerPorNombre(String nombre) throws Exception;
    List<ListaReproduccion> obtenerTodas() throws Exception;
    void crearLista(ListaReproduccion lista) throws SQLException;
    ListaReproduccion obtenerListaPorNombre(String nombre) throws SQLException;
    List<ListaReproduccion> listarListas() throws SQLException;
    void actualizarLista(ListaReproduccion lista) throws SQLException;
    void eliminarLista(String nombre) throws SQLException;
}
