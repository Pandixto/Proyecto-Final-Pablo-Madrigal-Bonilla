package DAO;

import Modelo.Usuario;

import java.sql.SQLException;
import java.util.List;

public interface UsuarioDAO {
    void insertar(Usuario usuario) throws Exception;
    void actualizar(Usuario usuario) throws Exception;
    void eliminar(String nombreUsuario) throws Exception;
    Usuario obtenerPorNombreUsuario(String nombreUsuario) throws Exception;
    List<Usuario> obtenerTodos() throws Exception;
    void crearUsuario(Usuario usuario) throws SQLException;
    Usuario obtenerUsuarioPorNombre(String nombreUsuario) throws SQLException;
    List<Usuario> listarUsuarios() throws SQLException;
    void actualizarUsuario(Usuario usuario) throws SQLException;
    void eliminarUsuario(String nombreUsuario) throws SQLException;
}
