package DAO;

import Modelo.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Modelo.UsuarioImpl;

public class UsuarioDAOImpl implements UsuarioDAO {

    private Connection conn;

    public UsuarioDAOImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void crearUsuario(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO USUARIOS (NOMBRE_COMPLETO, FECHA_NACIMIENTO, NACIONALIDAD, IDENTIFICACION, AVATAR, CORREO, NOMBRE_USUARIO, CONTRASENA, TIPO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNombreCompleto());
            stmt.setDate(2, Date.valueOf(usuario.getFechaNacimiento()));
            stmt.setString(3, usuario.getNacionalidad());
            stmt.setString(4, usuario.getIdentificacion());
            stmt.setString(5, usuario.getAvatar());
            stmt.setString(6, usuario.getCorreo());
            stmt.setString(7, usuario.getNombreUsuario());
            stmt.setString(8, usuario.getContrasena());
            stmt.executeUpdate();
        }
    }

    @Override
    public Usuario obtenerUsuarioPorNombre(String nombreUsuario) throws SQLException {
        String sql = "SELECT * FROM USUARIOS WHERE NOMBRE_USUARIO = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombreUsuario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new UsuarioImpl(
                    rs.getString("NOMBRE_COMPLETO"),
                    rs.getDate("FECHA_NACIMIENTO").toLocalDate(),
                    rs.getString("NACIONALIDAD"),
                    rs.getString("IDENTIFICACION"),
                    rs.getString("AVATAR"),
                    rs.getString("CORREO"),
                    rs.getString("NOMBRE_USUARIO"),
                    rs.getString("CONTRASENA"),
                    rs.getString("TIPO")
                );
            }
        }
        return null;
    }

    @Override
    public List<Usuario> listarUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM USUARIOS";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                usuarios.add(new UsuarioImpl(
                    rs.getString("NOMBRE_COMPLETO"),
                    rs.getDate("FECHA_NACIMIENTO").toLocalDate(),
                    rs.getString("NACIONALIDAD"),
                    rs.getString("IDENTIFICACION"),
                    rs.getString("AVATAR"),
                    rs.getString("CORREO"),
                    rs.getString("NOMBRE_USUARIO"),
                    rs.getString("CONTRASENA"),
                    rs.getString("TIPO")
                ));
            }
        }
        return usuarios;
    }

    @Override
    public void actualizarUsuario(Usuario usuario) throws SQLException {
        String sql = "UPDATE USUARIOS SET NOMBRE_COMPLETO = ?, FECHA_NACIMIENTO = ?, NACIONALIDAD = ?, IDENTIFICACION = ?, AVATAR = ?, CORREO = ?, CONTRASENA = ?, TIPO = ? WHERE NOMBRE_USUARIO = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNombreCompleto());
            stmt.setDate(2, Date.valueOf(usuario.getFechaNacimiento()));
            stmt.setString(3, usuario.getNacionalidad());
            stmt.setString(4, usuario.getIdentificacion());
            stmt.setString(5, usuario.getAvatar());
            stmt.setString(6, usuario.getCorreo());
            stmt.setString(7, usuario.getContrasena());
            stmt.setString(9, usuario.getNombreUsuario());
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminarUsuario(String nombreUsuario) throws SQLException {
        String sql = "DELETE FROM USUARIOS WHERE NOMBRE_USUARIO = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombreUsuario);
            stmt.executeUpdate();
        }
    }

    @Override
    public void insertar(Usuario usuario) throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'insertar'");
    }

    @Override
    public void actualizar(Usuario usuario) throws Exception {
 
     throw new UnsupportedOperationException("Unimplemented method 'actualizar'");
    }

    @Override
    public void eliminar(String nombreUsuario) throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'eliminar'");
    }

    @Override
    public Usuario obtenerPorNombreUsuario(String nombreUsuario) throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'obtenerPorNombreUsuario'");
    }

    @Override
    public List<Usuario> obtenerTodos() throws Exception {

     throw new UnsupportedOperationException("Unimplemented method 'obtenerTodos'");
    }
}
