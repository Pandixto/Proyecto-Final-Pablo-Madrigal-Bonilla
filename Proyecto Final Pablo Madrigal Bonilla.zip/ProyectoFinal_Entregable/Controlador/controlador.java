package Controlador;

import Modelo.*;
import Vista.VistaConsola;

import java.time.LocalDate;

public class controlador {
    private VistaConsola vista;
    private Reproductor reproductor;

    public controlador(VistaConsola vista) {
        this.vista = vista;
        this.reproductor = new Reproductor();
    }

    public void iniciar() {
        vista.mostrarMensaje("*** SPOTIFY ***");

        Administrador admin = new Administrador(
            "Pablo Madrigal",
            LocalDate.of(1999, 3, 30),
            "Costa Rica",
            "12345678",
            null,
            "pablo@yahoo.com",
            "Administrador",
            "Admin1234."
        );

        UsuarioFinal user = new UsuarioFinal(
            "Daniela Segura",
            LocalDate.of(1997, 12, 25),
            "Costa Rica",
            "87654321",
            null,
            "daniela@gmail.com",
            "dsegura",
            "Dani#2025"
        );

        Cancion cancion = new Cancion(
            1,
            "Smooth Criminal",
            "Pop",
            "Michael Jackson",
            "Michael Jackson y Quincy Jones",
            LocalDate.of(1987, 11, 14),
            "Epic",
            9.99
        );
        cancion.agregarCalificacion(9);
        cancion.agregarCalificacion(8);

        ListaReproduccion lista = new ListaReproduccion("Favoritas");
        lista.agregarCancion(cancion);

        vista.mostrarUsuario(admin);
        vista.mostrarUsuario(user);

        vista.mostrarCancion(cancion);
        vista.mostrarMensaje("Calificación promedio: " + cancion.getCalificacionPromedio());

        vista.mostrarListaReproduccion(lista);
        vista.mostrarMensaje("Calificación promedio de la lista de reproducción: " + lista.getCalificacionPromedio());

        reproductor.reproducir(cancion);

        Cancion cancionActual = reproductor.getCancionActual();
        if (cancionActual != null) {
            vista.mostrarMensaje("Canción actual: " +
                cancionActual.getNombre() + " - " +
                cancionActual.getArtista() + " - (" +
                cancionActual.getAlbum() + ")"
            );
        } else {
            vista.mostrarMensaje("No hay canciones en reproducción");
        }
    }
}
