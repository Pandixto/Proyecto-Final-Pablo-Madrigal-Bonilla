package Controlador;

import Vista.VistaConsola;

public class Main {
    public static void main(String[] args) {
        VistaConsola vista = new VistaConsola();
        controlador controlador = new controlador(vista);
        controlador.iniciar();
    }
}
